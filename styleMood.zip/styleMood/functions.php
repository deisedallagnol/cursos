<?php
/* WIDGETS */

if (function_exists('register_sidebar'))
{
    register_sidebar(array(
		'name'			=> 'Sidebar',
        'before_widget'	=> '<div class="widget">',
        'after_widget'	=> '</div>',
		'before_title'	=> '<h3>',
		'after_title'	=> '</h3><br>',
    ));
}


	
	
	


/**
 * Widget de Sobre o Autor
 * 
 * @author Thiago Belem <contato@thiagobelem.net>
 * @link http://blog.thiagobelem.net/criando-seu-primeiro-widget-no-wordpress/
 */
class SobreAutorWidget extends WP_Widget {
    
    /**
     * Construtor
     */
    public function SobreAutorWidget() {
        parent::WP_Widget(false, $name = 'Sobre o autor');
    }
    
    /**
     * Exibição final do Widget (já no sidebar)
     *
     * @param array $argumentos Argumentos passados para o widget
     * @param array $instancia Instância do widget
     */
    public function widget($argumentos, $instancia) {
        if (!is_single()) return;
        
        $autor = array(
            'nome' => get_the_author_meta('display_name'),
            'email' => get_the_author_meta('user_email'),
            'descricao' => get_the_author_meta('description'),
            'link' => get_the_author_meta('user_url')
        );
        
        // Exibe o HTML do Widget
        echo $argumentos['before_widget'];
		
		if ( ! empty( $instancia['title'] ) ) {
			echo $argumentos['before_title'] . apply_filters( 'widget_title', $instancia['title'] ). $argumentos['after_title'];
		}else{echo $argumentos['before_title'] . $argumentos['widget_name'] . $argumentos['after_title'];}
        echo get_avatar($autor['email'], $size = '250');
        echo "<h4>{$autor['nome']}</h4>";
        echo "<p>{$autor['descricao']}</p>";
        if (isset($instancia['link_autor']) && $instancia['link_autor']) {
            echo '<p>Visite o <a href="'. $autor['link'] .'" title="'. $autor['nome'] .'" rel="nofollow" target="_blank">site do autor</a></p>';
        }
        echo $argumentos['after_widget'];
    }
    
    /**
     * Salva os dados do widget no banco de dados
     *
     * @param array $nova_instancia Os novos dados do widget (a serem salvos)
     * @param array $instancia_antiga Os dados antigos do widget
     * 
     * @return array $instancia Dados atualizados a serem salvos no banco de dados
     */
    public function update($nova_instancia, $instancia_antiga) {
        $instancia = array_merge($instancia_antiga, $nova_instancia);
		$instancia['title'] = ( ! empty( $nova_instancia['title'] ) ) ? strip_tags( $nova_instancia['title'] ) : '';
        
        return $instancia;
    }
    
    /**
     * Formulário para os dados do widget (exibido no painel de controle)
     *
     * @param array $instancia Instância do widget
     */
    public function form($instancia) {
        $widget['link_autor'] = (boolean)$instancia['link_autor'];
		$title = ! empty( $instancia['title'] ) ? $instancia['title'] : __( 'New title', 'text_domain' );
        ?>
        <p><label for="<?php echo $this->get_field_id('link_autor'); ?>"><input id="<?php echo $this->get_field_id('link_autor'); ?>" name="<?php echo $this->get_field_name('link_autor'); ?>" type="checkbox" value="1" <?php if ($widget['link_autor']) echo 'checked="checked"'; ?> /> <?php _e('Exibe o link do autor'); ?></label></p>
        
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php    
    }
    
}


// register Foo_Widget widget
function register_auto() {
    register_widget( 'SobreAutorWidget' );
}
add_action( 'widgets_init', 'register_auto' );





// Enable support for Post Thumbnails, and declare two sizes.
add_theme_support( 'post-thumbnails' );
//set_post_thumbnail_size( 200, 200);

add_image_size( 'grande', 400, 400, true );
add_image_size( 'imgcategoria', 260, 260, true );
add_image_size( 'media', 200, 200, true );
add_image_size( 'pequena', 90, 90, true );

add_theme_support( 'post-formats', array( 'aside', 'gallery','link','image','quote','status','video','audio','chat' ) );


//habilita a função de menus personalizados que tem no sistema
if ( function_exists( 'register_nav_menu' ) ) {
    register_nav_menu( 'menu_principal', 'Menu principal' );
    register_nav_menu( 'menu_rodape', 'Menu do rodapé');
}


// Pagination
function wp_pagination($pages = '', $range = 9)
{  
    global $wp_query, $wp_rewrite;  
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;  
    $pagination = array(  
        'base' => @add_query_arg('paged','%#%'),  
        'format' => '',  
        'total' => $wp_query->max_num_pages,  
        'current' => $current,  
        'show_all' => true,  
        'type' => 'plain'  
    );  
    if ( $wp_rewrite->using_permalinks() ) $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );  
    if ( !empty($wp_query->query_vars['s']) ) $pagination['add_args'] = array( 's' => get_query_var( 's' ) );  
    echo '<div class="wp_pagination">'.paginate_links( $pagination ).'</div>';
}

?>