<?php get_header();?>
<div class="painel">
<div class="back-black"></div>
	<div id="content" class="page">		
		<div class="wrap">	
				<img src="<?=bloginfo('template_url')?>/img/close.png" class="btn-close">		
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="artigo">
						<h1 class="title"><span><?php the_title(); ?></span></h1>
						<?php the_content(); ?>
					</div>
				<?php endwhile; else: ?>
					<div class="artigo">
						<h2>Nada Encontrado</h2>
						<p>Erro 404</p>
						<p>Lamentamos mas não foram encontrados artigos.</p>
					</div>			
				<?php endif; ?>
				
			</div>				
	</div>
</div>
<?php get_footer(); ?>