<?php get_header(); ?>
	<div id="content">
		<div id="showcase">
			<img src="<?=bloginfo('template_url')?>/img/carousel.jpg" alt="<?php bloginfo('name'); ?>">
			<?php echo do_shortcode("[huge_it_slider id='1']"); ?>
		</div>
				
		<div class="wrap">
			<div id="left">
				<div class="posts">
		 			<?php global $query_string; parse_str( $query_string, $my_query_array ); 
					$paged = ( isset( $my_query_array['paged'] ) && !empty( $my_query_array['paged'] ) ) ? $my_query_array['paged'] : 1;?> 
					<?php query_posts("cat=2&showposts=6&paged=$paged"); 
					//query_posts( array ( 'category_name' => 'home', 'showposts' => '6', 'paged' => $paged ) );
					?> 

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="card-post">
				
						<?php //if ( has_post_thumbnail( $_post->ID ) ) {
							
        echo '<a class="lkp" href="' . get_permalink( $_post->ID ) . '" title="' . esc_attr( $_post->post_title ) . '">';?>
		<div class="card-read-more"></div>
		<?php
        echo get_the_post_thumbnail( $_post->ID, 'media' );
		echo $_post->post_title;
		?>
		<div class="bottom">
			
		</div>
		<?php
        echo '</a>';
    //}?>
						<!--<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
						<p>Postado por <?php the_author() ?> em <?php the_time('d/M/Y') ?> - <?php comments_popup_link('Sem Comentários', '1 Comentário', '% Comentários', 'comments-link', ''); ?> <?php edit_post_link('(Editar)'); ?></p>
						<p><?php the_content(); ?></p>-->
							</div>
				<?php endwhile?>
				</div>
				<div class="load">
						<img src="<?=bloginfo('template_url')?>/img/load.gif">
				</div>
					<div class="navegacao">
						<?php  //wp_pagination();?>
						<div class="recentes"><?php next_posts_link('&laquo; Artigos Anteriores') ?></div>
						<div class="anteriores"><?php previous_posts_link('Artigos Recentes &raquo;') ?></div>
					</div>
				<?php else: ?>
					<div class="artigo">
						<h2>Nada Encontrado</h2>
						<p>Erro 404</p>
						<p>Lamentamos mas não foram encontrados artigos.</p>
					</div>			
				<?php endif; ?>
				
			</div>
			
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>