<?php get_header();?>
<div class="painel-post" style="position: absolute; width: 100%;">
<div class="back-black"></div>
	<div id="content" class="post">
			<div class="wrap">
		<div id="left">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<div class="artigo">
					<h1 class="title"><?php the_title(); ?></h1>
					<p class="data"><?php the_time('d. M .Y') ?></p>
					<?php the_content(); ?>
					
					
					<?php
$randomPost = $wpdb->get_var("SELECT guid FROM $wpdb->posts WHERE post_type = 'post' AND post_status = 'publish' ORDER BY rand() LIMIT 1");
$categories = get_the_category($post->ID);
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'showposts'=>3,
'caller_get_posts'=>1
);
$my_query = new wp_query($args);
if( $my_query->have_posts() ) {
echo '<div id="postsRelacionados">posts Relacionados';
while ($my_query->have_posts()) {
$my_query->the_post();


?>

<div class="conteudoRelacionados">
<div class="fotoRelacionados"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'pequena' ); } ?></a></div>
<div class="tituloRelacionados"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></div>
<div class="textoRelacionados"><?php //echo excerpt(10); ?></div>
</div>
<?php
}
echo '</div>';
}
}
?>
				</div>
				
				<?php comments_template(); ?>
					
			<?php endwhile; else: ?>
				<div class="artigo">
					<h2>Nada Encontrado</h2>
					<p>Erro 404</p>
					<p>Lamentamos mas não foram encontrados artigos.</p>
				</div>			
			<?php endif; ?>
			
		</div>
		
		<?php get_sidebar(); ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>