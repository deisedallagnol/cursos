<?php //$query = new WP_Query( 'cat=9' ); ?>
			 <?php //query_posts( 'category_name=home&posts_per_page=3' ); ?>
			 <?php global $query_string; parse_str( $query_string, $my_query_array ); 
$paged = ( isset( $my_query_array['paged'] ) && !empty( $my_query_array['paged'] ) ) ? $my_query_array['paged'] : 1;?> 
<?php query_posts("cat=9&showposts=6&paged=$paged"); ?> 
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="card-post">
				
						<?php //if ( has_post_thumbnail( $_post->ID ) ) {
							
        echo '<a href="' . get_permalink( $_post->ID ) . '" title="' . esc_attr( $_post->post_title ) . '">';?>
		<div class="card-read-more"></div>
		<?php
        echo get_the_post_thumbnail( $_post->ID, 'media' );
		echo $_post->post_title;
		echo '<span>read <br><b>more</b></span>';
        echo '</a>';
    //}?>
						<!--<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
						<p>Postado por <?php the_author() ?> em <?php the_time('d/M/Y') ?> - <?php comments_popup_link('Sem Comentários', '1 Comentário', '% Comentários', 'comments-link', ''); ?> <?php edit_post_link('(Editar)'); ?></p>
						<p><?php the_content(); ?></p>-->
							</div>
				<?php endwhile?>