<div id="footer">
	<div class="wrap">
		<a href=""><img src="<?=bloginfo('template_url')?>/img/logo_footer.png"></a>
		<ul class="links">
			<?php //wp_list_cats('sort_column=name'); 
			wp_nav_menu( array(
				'menu' => 'menu_rodape',
				'theme_location' => 'menu_rodape',
				'echo' => true,
				'depth' => 0,
				'walker' =>'',
				) );
			?>
		</ul>
		<?php wp_footer(); ?>
	</div>
</div>
	

<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

</body>
</html>