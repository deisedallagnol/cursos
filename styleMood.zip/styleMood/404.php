<?php get_header(); ?>
	<div id="conteudo">
		<div id="artigos">
			<div class="artigo">
				<h1>Erro 404 - Não Encontrado</h1>
				<p>Lamentamos, mas o que você procura não foi encontrado.</p>
			</div>
		</div>
		
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>