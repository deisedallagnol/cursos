$(document).ready(function() {
    
    

   
    
    //paginação via ajax
    $(document.body).on('click', '.recentes a', function(event){
        event.preventDefault();
        $('.load').css('display','block');
        
        var pagina = $(this).attr('href'); 

        $.ajax({     
            method: "POST",      
            url : pagina,            
            data : "",  
            dataType: "html",          
            cache: false,            
            success: function(data, textStatus, jqXHR){
                $(".load").css('display','none');
                var conteudo = $(data).find('.posts');
                $(".posts").append(conteudo); 
            },
            error: function(jqXHR, textStatus, errorThrown){                
                $('.load').css('display','none');
                $( ".posts" ).append('Não foi possível carregar mais posts.');     
            }
        });
    });



    //abre a categoria
    //$(document.body).on('click', '#nav li a', function(event){
    $('#nav li a').on('click', function(event){
        event.preventDefault();              
        var pagina = $(this).attr('href'); 

        $.ajax({     
            method: "POST",      
            url : pagina,            
            data : "",  
            dataType: "html",          
            cache: false,            
            success: function(data, textStatus, jqXHR){
                $(".modal").empty();
                $(".modal").css('display','block');    
                //var conteudo1 = $(data).find('.back-white');
                var conteudo = $(data).filter('.painel');
                console.log(conteudo);
               // $(".modal").append(conteudo1);  
               history.pushState(pagina, '', pagina);
               $(".modal").append(conteudo);  

               $(".btn-close").css('display','block');

                $(document.body).on('click', '.back-white', function(){
                    $('.modal').css('display','none');
                });

                $(document.body).on('click', '.btn-close', function(){
                    $('.modal').css('display','none');
                });
            },
            error: function(jqXHR, textStatus, errorThrown){                
                $( "#left" ).append('Não foi possível carregar a categoria.');     
            }
        });
    });

    //abre o post
    $(document.body).on('click', '.lkp', function(event){
        event.preventDefault();
        var pagina = $(this).attr('href');            

        $.ajax({     
            method: "POST",      
            url : pagina,            
            data : "",
            dataType: "html",          
            cache: false,
            success: function(data, textStatus, jqXHR){
                $(".modal").empty();
                $(".modal").css('display','block');   

                //$(".modal").append(data);

                var conteudo = $(data).filter('.painel-post');
               
               $(".modal").append(conteudo); 

               $(".btn-close").css('display','block');

                history.pushState(pagina, '', pagina);  

                $(document.body).on('click', '.back-black', function(){
                    $('.modal').css('display','none');
                });    

                $(document.body).on('click', '.btn-close', function(){
                    $('.modal').css('display','none');
                });             
            },
            error: function(jqXHR, textStatus, errorThrown){                
                $( "#left" ).append('Não foi possível carregar o post.');     
            }
        });
    });

    //abre o post na página de categoria
    $(document.body).on('click', '.lkpc', function(event){
        event.preventDefault();
        var pagina = $(this).attr('href');            

        $.ajax({     
            method: "POST",      
            url : pagina,            
            data : "",
            dataType: "html",          
            cache: false,
            success: function(data, textStatus, jqXHR){
               

                //$(".modal").empty();
                //$(".modal").css('display','block');                
                //$(".modal").append(data);  

                var conteudo = $(data).filter('.painel-post');
               
               $(".modal").append(conteudo); 

               $(".btn-close").css('display','block');

                $(document.body).on('click', '.back-black', function(){
                    $('.painel-post').remove();
                }); 

                $(document.body).on('click', '.btn-close', function(){
                    $('.painel-post').remove();
                });                 
            },
            error: function(jqXHR, textStatus, errorThrown){                
                $( "#left" ).append('Não foi possível carregar o post.');     
            }
        });
    });



    var nav = $('.back-black');   
            $(window).scroll(function () { 
               
                if ($(window).scrollTop() >= 15) { 
                    console.log($(window).scrollTop());
                    $('.back-black').css('margin-top','0'); 
                   
                } else { 
                    
                    $('.back-black').css('margin-top','165px');  
                } 
            });
});