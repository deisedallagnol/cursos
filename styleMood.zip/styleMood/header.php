<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>

<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title(''); ?></title>

<meta property="og:url"           content="http://www.your-domain.com/your-page.html" />
<meta property="og:type"          content="website" />
<meta property="og:title"         content="<?php wp_title(''); ?>" />
<meta property="og:description"   content="<?php bloginfo('description'); ?>" />
<meta property="og:image"         content="http://www.your-domain.com/path/image.jpg" />

<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="<?=bloginfo('template_url')?>/js/functions.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); wp_head(); ?>

</head>
<body>
<div id="header">
	<div class="wrap">
		<div class="header-top">
			<a href="">/ CHAT WITH US</a>
		</div>

		<div class="header-mid">
			<a href="<?php echo home_url( '/' )?>" class="logo">
				<img src="<?=bloginfo('template_url')?>/img/logo.png" alt="<?php bloginfo('name'); ?>">
			</a>

			<div class="col1">
				<ul class="social-links">
					<li><a href="http://instagram.com/stylemood__" target="_blank"><img src="<?=bloginfo('template_url')?>/img/icon-instagram.png" alt="Instagram"></a></li>
					<li><a href="http://www.facebook.com/SiteStyleMood/" target="_blank"><img src="<?=bloginfo('template_url')?>/img/icon-facebook.png" alt="Facebook"></a></li>
					<li><a href="https://www.youtube.com/channel/UCckcXkhcoeIhBVr6Cf_DZEA" target="_blank"><img src="<?=bloginfo('template_url')?>/img/icon-youtube.png" alt="YouTube"></a></li>
					<li><a href="https://www.pinterest.com/stylemood__/" target="_blank"><img src="<?=bloginfo('template_url')?>/img/icon-pinterest.png" alt="Pinterest"></a></li>
				</ul>
				
				<div class="search-box">
					<form role="search" method="get" id="searchform" class="searchform" action="http://localhost/wordpress/">
						<input type="text" value="" name="s" id="s" placeholder="SEARCH" class="field">
						<input type="submit" id="searchsubmit" value="Pesquisar" class="button">
					</form>
				</div>
			</div>
		</div>
		
		<ul id="nav">
			<?php //wp_list_cats('sort_column=name'); 
			wp_nav_menu( array(
				'menu' => 'menu_principal',
				'theme_location' => 'menu_principal',
				'echo' => true,
				'depth' => 0,
				'walker' =>'',
				) );
			?>
		</ul>
	</div>
</div>
<div class="modal">
</div>