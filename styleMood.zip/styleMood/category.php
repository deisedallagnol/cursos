<?php get_header();?>
<div class="painel" style="position: absolute; width: 100%;">
<div class="back-white"></div>
<div id="content" class="category">
		
		<div class="wrap">
		<img src="<?=bloginfo('template_url')?>/img/close.png" class="btn-close">
		<h1 class="title"><?php echo single_cat_title('', false); ?></h1>
		
			<div id="left">
				<?php global $query_string; parse_str( $query_string, $my_query_array ); 
				$paged = ( isset( $my_query_array['paged'] ) && !empty( $my_query_array['paged'] ) ) ? $my_query_array['paged'] : 1;?> 
				<?php //query_posts("showposts=6&paged=$paged"); ?> 
			
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="card-post">
				
						<?php if ( has_post_thumbnail( $_post->ID ) ) {
							
        echo "<a href='" . get_permalink( $_post->ID ) . "' title='' class='lkpc'>";?>
		
		<?php
        echo get_the_post_thumbnail( $_post->ID, 'imgcategoria' );
         echo "</a>";

		if (has_excerpt() ) {
the_excerpt();
 }

echo "<div class='bottom'>";
 
 global $post;
$tag_ids = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
echo "<a href='' class='tag'>".$tag_ids[0]."</a>";
		echo"</div>";
       
    }?>
				<div class="fb-share-button" 
        data-href="<?php echo get_permalink( $_post->ID )?> " 
        data-layout="button_count">
        <ul class="compartilhe">
        	<li><a href=""><img src="<?=bloginfo('template_url')?>/img/icon-facebook.png" alt="Facebook"></a></li>
        </ul>
    </div>
							</div>
				<?php endwhile?>
					<div class="navegacao">
					<?php  wp_pagination();?>
						<div class="recentes"><?php next_posts_link('&laquo; Artigos Anteriores') ?></div>
						<div class="anteriores"><?php previous_posts_link('Artigos Recentes &raquo;') ?></div>
					</div>
				<?php else: ?>
					<div class="artigo">
						<h2>Nada Encontrado</h2>
						
						<p>Lamentamos mas não foram encontrados artigos.</p>
					</div>			
				<?php endif; ?>
				
			</div>
			
			
		</div>
	</div>
</div>
<?php get_footer(); ?>