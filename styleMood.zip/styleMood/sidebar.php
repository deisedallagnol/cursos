<div id="sidebar">
    <?php if(is_single()){?>
        <img src="<?=bloginfo('template_url')?>/img/close.png" class="btn-close">
        <div class="widget">
            <h3>today's mood</h3>
            <div class="bolls">
                <?php   
                    $posts = get_posts( array( 'posts_per_page' => 6, 'category_name' => 'home' ) );
                    foreach ( $posts as $_post ) {
                        if ( has_post_thumbnail( $_post->ID ) ) {
                                echo "<a href='" . get_permalink( $_post->ID ) . "title='" . esc_attr( $_post->post_title ) . " class='lkp'>";
                                echo get_the_post_thumbnail( $_post->ID, 'pequena' );
                                echo "</a>";
                        }
                    }
                ?>
            </div>
        </div>
    <?php }else{ ?>
    <div class="widget">
        <h3>today's board</h3>
        <div class="bolls">
    		<?php	
                $posts = get_posts( array( 'posts_per_page' => 6, 'category_name' => 'home' ) );
                foreach ( $posts as $_post ) {
                    if ( has_post_thumbnail( $_post->ID ) ) {
                            echo "<a href='" . get_permalink( $_post->ID ) . "' title='" . esc_attr( $_post->post_title ) . "' class='lkp'>";
                            echo get_the_post_thumbnail( $_post->ID, 'pequena' );
                            echo "</a>";
                    }
                }
            ?>
        </div>
    </div>

    <div class="widget">
        <h3>wishlist</h3>
        <div class="wish-box">
            <?php   
                $posts = get_posts( array( 'posts_per_page' => 1, 'category_name' => 'home' ) );
                foreach ( $posts as $_post ) {
                    if ( has_post_thumbnail( $_post->ID ) ) {
                            echo '<a href="' . get_permalink( $_post->ID ) . '" title="' . esc_attr( $_post->post_title ) . '">';
                            echo get_the_post_thumbnail( $_post->ID, 'media' );
                            echo '</a>';
                    }
                }
            ?>
        </div>
    </div>

    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?><?php endif; ?>
	<?php } ?>	
</div>